<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/content/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'content.home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/auth/admin/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.auth.admin.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/auth/admin/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.auth.admin.forgot-password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/auth/admin/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.auth.admin.reset-password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/auth/customer/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.auth.customer.register',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/auth/customer/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.auth.customer.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/auth/customer/google/redirect' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.auth.customer.google.redirect',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/auth/customer/google/callback' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.auth.customer.google.callback',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/auth/customer/google/id-token' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.auth.customer.google.id-token',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.products.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/categories/tree' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.tree',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/categories/featured' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.featured',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/categories/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/brands' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.brands.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/webhooks/fedapay' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.webhooks.fedapay',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.me',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/users/super-admins/count' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.users.super-admins.count',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.users.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.profile.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.profile.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/profile/avatar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.profile.avatar.upload',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.profile.avatar.delete',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/profile/change-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.profile.password.change',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/authenticity/generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.authenticity.generate',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/authenticity/analytics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.authenticity.analytics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/collections-seasons' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.seasons',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/collections-featured' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.featured',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/collections/products/available' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.products.available',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/collections/products/bulk-move' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.products.bulk-move',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/collections' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/products/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/products/bulk/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.bulk.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/products/bulk/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.bulk.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/products/bulk/restore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.bulk.restore',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/products/bulk/force-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.bulk.force-delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/products/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.export',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/categories/tree' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.tree',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/categories/reorder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.reorder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/categories/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/categories/bulk/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.bulk.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/categories/bulk/force-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.bulk.force-delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/brands/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/brands/bulk/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.bulk.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/brands/bulk/force-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.bulk.force-delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/brands' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/attributes/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/attributes/reorder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.reorder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/attributes/bulk/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.bulk.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/attributes/bulk/force-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.bulk.force-delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/attributes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/preorders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.preorders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.orders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/payments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.payments.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/customers/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/customers/bulk/status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.bulk.status',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/customers/bulk/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.bulk.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/customers/bulk/force-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.bulk.force-delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/settings/members/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.members.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/settings/members' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.members.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.members.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/settings/invitations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.invitations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.invitations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/settings/invitations/bulk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.invitations.bulk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/promotions/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/promotions/bulk/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.bulk.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/promotions/bulk/restore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.bulk.restore',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/promotions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/reviews/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/reviews/bulk/approve' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.bulk.approve',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/reviews/bulk/reject' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.bulk.reject',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/reviews/bulk/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.bulk.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/reviews/bulk/restore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.bulk.restore',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/reviews' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/shipments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipments.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipments.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/shipping-methods' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipping-methods.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipping-methods.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory/notification-settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.notification-settings.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.notification-settings.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory/low-stock' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.low-stock',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory/movements' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.movements',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory/statistics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.statistics',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory/out-of-stock' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.out-of-stock',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory/adjust' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.adjust',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory/bulk-adjust' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.bulk-adjust',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/inventory/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.inventory.export',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/dashboard/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.dashboard.stats',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.me',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/profile/change-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.profile.change-password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/addresses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.addresses.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.addresses.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.cart.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.cart.clear',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/cart/items' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.cart.add-item',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/cart/coupon' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.cart.apply-coupon',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.cart.remove-coupon',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/cart/convert-to-gift' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.cart.convert-gift',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/gift-carts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.gift-carts.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.orders.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.orders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/preorders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.preorders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/reviews' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.reviews.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.reviews.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.wishlist.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.wishlist.add',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.wishlist.clear',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/notifications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.notifications.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/notifications/unread-count' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.notifications.unread-count',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/notifications/read-all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.notifications.read-all',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yj8Uvs3vzt5r2iCA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dm8q34KPf0wZM6WV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/docs/api' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scramble.docs.ui',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/docs/api.json' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scramble.docs.document',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/v1/(?|verify\\-qr/([^/]++)(*:37)|c(?|atalog/(?|products/([^/]++)(?|(*:78)|/preorder\\-info(*:100))|categories/(?|by\\-genre/(homme|femme|enfant|mixte)(*:159)|([a-z0-9-]+)(*:179)|([a-z0-9-]+)/products(*:208)|([a-z0-9-]+)/breadcrumb(*:239)|([a-z0-9-]+)/related(*:267)))|ustomer/(?|addresses/([^/]++)(?|(*:309)|/set\\-default(*:330))|cart/items/([^/]++)(?|(*:361))|gift\\-carts/([^/]++)/cancel(*:397)|orders/([^/]++)(?|(*:423)|/cancel(*:438))|reviews/([^/]++)(?|(*:466))|wishlist/([\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12})(?|/check(*:565)|(*:573))|notifications/([\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12})/read(*:673)))|gift\\-carts/([^/]++)(?|(*:706)|/contribut(?|e(*:728)|ions(*:740)))|admin/(?|users/([^/]++)(?|(*:776))|a(?|uthenticity/(?|([^/]++)/mark\\-fake(*:823)|product/([^/]++)/stats(*:853))|ttributes/(?|([^/]++)/(?|restore(*:894)|force(*:907))|bulk/restore(*:928)|([^/]++)(?|(*:947))))|c(?|ollections/([^/]++)(?|(*:984)|/(?|toggle\\-(?|featured(*:1015)|active(*:1030))|products/(?|add(*:1055)|remove(*:1070)|s(?|ync(*:1086)|tatistics(*:1104)))|statistics(*:1125)|refresh\\-counts(*:1149)|archive(*:1165)))|ategories/(?|([^/]++)/(?|move(*:1205)|restore(*:1221)|breadcrumb(*:1240)|force(*:1254))|bulk/restore(*:1276)|([^/]++)(?|(*:1296)))|ustomers/(?|([^/]++)(?|(*:1330)|/(?|suspend(*:1350)|activate(*:1367)|deactivate(*:1386)|restore(*:1402)))|bulk/restore(*:1425)|([^/]++)/force(*:1448)|export(*:1463)))|p(?|ro(?|ducts/([^/]++)(?|/(?|d(?|uplicate(*:1516)|isable\\-preorder(*:1541))|restore(*:1558)|force(*:1572)|stock(?|(*:1589)|\\-history(*:1607))|variations/([^/]++)/stock(*:1642)|enable\\-preorder(*:1667)|preorder(?|\\-info(*:1693)|/(?|enable(*:1712)|disable(*:1728)))|authenticity/stats(*:1757))|(*:1767))|motions/([^/]++)(?|/restore(*:1804)|(*:1813)))|ayments/([^/]++)(?|(*:1843)|/refund(*:1859)))|brands/(?|([^/]++)/(?|restore(*:1899)|force(*:1913))|bulk/restore(*:1935)|([^/]++)(?|(*:1955)))|orders/([^/]++)(?|(*:1984)|/(?|items(*:2002)|status(*:2017)|cancel(*:2032)))|s(?|ettings/(?|members/([\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12})(?|(*:2141)|/(?|role(*:2158)|status(*:2173)))|invitations/([\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12})(?|/resend(*:2278)|(*:2287)))|hip(?|ments/([^/]++)(?|(*:2321))|ping\\-methods/([^/]++)(?|(*:2356))))|reviews/([^/]++)(?|/(?|re(?|store(*:2401)|ject(*:2414))|approve(*:2431))|(*:2441))))|/storage/(.*)(*:2466))/?$}sDu',
    ),
    3 => 
    array (
      37 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.verify-qr',
          ),
          1 => 
          array (
            0 => 'qrCode',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      78 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.products.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      100 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.products.preorder-info',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      159 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.by-genre',
          ),
          1 => 
          array (
            0 => 'genre',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      179 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.show',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      208 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.products',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      239 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.breadcrumb',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      267 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.catalog.categories.related',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      309 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.addresses.show',
          ),
          1 => 
          array (
            0 => 'address',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.addresses.update',
          ),
          1 => 
          array (
            0 => 'address',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.addresses.destroy',
          ),
          1 => 
          array (
            0 => 'address',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      330 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.addresses.set-default',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      361 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.cart.update-item',
          ),
          1 => 
          array (
            0 => 'itemId',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.cart.remove-item',
          ),
          1 => 
          array (
            0 => 'itemId',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      397 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.gift-carts.cancel',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      423 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.orders.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      438 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.orders.cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      466 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.reviews.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.reviews.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      565 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.wishlist.check',
          ),
          1 => 
          array (
            0 => 'productId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      573 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.wishlist.remove',
          ),
          1 => 
          array (
            0 => 'productId',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      673 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.customer.notifications.read',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      706 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.gift-carts.show',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.gift-carts.contribute',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      740 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.gift-carts.contributions',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      776 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.users.show',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.users.update',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.users.destroy',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      823 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.authenticity.mark-fake',
          ),
          1 => 
          array (
            0 => 'qrCode',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      853 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.authenticity.product-stats',
          ),
          1 => 
          array (
            0 => 'productId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      894 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      907 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.force-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      928 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.bulk.restore',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      947 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.show',
          ),
          1 => 
          array (
            0 => 'attribute',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.update',
          ),
          1 => 
          array (
            0 => 'attribute',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.attributes.destroy',
          ),
          1 => 
          array (
            0 => 'attribute',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      984 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.show',
          ),
          1 => 
          array (
            0 => 'collection',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.update',
          ),
          1 => 
          array (
            0 => 'collection',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.destroy',
          ),
          1 => 
          array (
            0 => 'collection',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1015 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.toggle-featured',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1030 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.toggle-active',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1055 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.products.add',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1070 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.products.remove',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1086 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.products.sync',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.products.statistics',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1125 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.statistics',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1149 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.refresh-counts',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.collections.archive',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1205 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.move',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1221 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1240 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.breadcrumb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1254 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.force-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1276 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.bulk.restore',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1296 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.show',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.update',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.categories.destroy',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1330 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.show',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.update',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.destroy',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1350 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.suspend',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1386 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.deactivate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1402 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.bulk.restore',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1448 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.force-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1463 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.customers.export',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1516 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.duplicate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1541 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.disable-preorder',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1558 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1572 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.force-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1589 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.update-stock',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1607 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.stock-history',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1642 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.variations.update-stock',
          ),
          1 => 
          array (
            0 => 'productId',
            1 => 'variationId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1667 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.enable-preorder',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1693 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.preorder-info',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1712 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.preorder.enable',
          ),
          1 => 
          array (
            0 => 'productId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.preorder.disable',
          ),
          1 => 
          array (
            0 => 'productId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1757 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.authenticity.stats',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1767 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.show',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.update',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.products.destroy',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1804 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1813 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.show',
          ),
          1 => 
          array (
            0 => 'promotion',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.update',
          ),
          1 => 
          array (
            0 => 'promotion',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.promotions.destroy',
          ),
          1 => 
          array (
            0 => 'promotion',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1843 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.payments.show',
          ),
          1 => 
          array (
            0 => 'payment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1859 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.payments.refund',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1899 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1913 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.force-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1935 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.bulk.restore',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1955 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.update-with-files',
          ),
          1 => 
          array (
            0 => 'brand',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.show',
          ),
          1 => 
          array (
            0 => 'brand',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.update',
          ),
          1 => 
          array (
            0 => 'brand',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.brands.destroy',
          ),
          1 => 
          array (
            0 => 'brand',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1984 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.orders.show',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.orders.destroy',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2002 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.orders.items',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2017 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.orders.update-status',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2032 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.orders.cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2141 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.members.show',
          ),
          1 => 
          array (
            0 => 'member',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.members.update',
          ),
          1 => 
          array (
            0 => 'member',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.members.destroy',
          ),
          1 => 
          array (
            0 => 'member',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2158 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.members.update-role',
          ),
          1 => 
          array (
            0 => 'member',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.members.update-status',
          ),
          1 => 
          array (
            0 => 'member',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.invitations.resend',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2287 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.settings.invitations.cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2321 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipments.show',
          ),
          1 => 
          array (
            0 => 'shipment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipments.update',
          ),
          1 => 
          array (
            0 => 'shipment',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipments.destroy',
          ),
          1 => 
          array (
            0 => 'shipment',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2356 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipping-methods.show',
          ),
          1 => 
          array (
            0 => 'shipping_method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipping-methods.update',
          ),
          1 => 
          array (
            0 => 'shipping_method',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.shipping-methods.destroy',
          ),
          1 => 
          array (
            0 => 'shipping_method',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2401 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.restore',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2414 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.reject',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2431 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.approve',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.show',
          ),
          1 => 
          array (
            0 => 'review',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.reviews.destroy',
          ),
          1 => 
          array (
            0 => 'review',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2466 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.verify-qr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/verify-qr/{qrCode}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:30,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@verify',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@verify',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'api.verify-qr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'content.home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/content/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'Modules\\Core\\Http\\Controllers\\HomeContentController@index',
        'controller' => 'Modules\\Core\\Http\\Controllers\\HomeContentController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'content.home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.auth.admin.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/auth/admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:5,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\AuthController@login',
        'controller' => 'Modules\\User\\Http\\Controllers\\AuthController@login',
        'as' => 'api.auth.admin.login',
        'namespace' => NULL,
        'prefix' => 'api/v1/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.auth.admin.forgot-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/auth/admin/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:3,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\AuthController@forgotPassword',
        'controller' => 'Modules\\User\\Http\\Controllers\\AuthController@forgotPassword',
        'as' => 'api.auth.admin.forgot-password',
        'namespace' => NULL,
        'prefix' => 'api/v1/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.auth.admin.reset-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/auth/admin/reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:3,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\AuthController@resetPassword',
        'controller' => 'Modules\\User\\Http\\Controllers\\AuthController@resetPassword',
        'as' => 'api.auth.admin.reset-password',
        'namespace' => NULL,
        'prefix' => 'api/v1/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.auth.customer.register' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/auth/customer/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'throttle:5,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@register',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@register',
        'as' => 'api.auth.customer.register',
        'namespace' => NULL,
        'prefix' => 'api/v1/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.auth.customer.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/auth/customer/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'throttle:10,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@login',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@login',
        'as' => 'api.auth.customer.login',
        'namespace' => NULL,
        'prefix' => 'api/v1/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.auth.customer.google.redirect' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/auth/customer/google/redirect',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'throttle:10,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@googleRedirect',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@googleRedirect',
        'as' => 'api.auth.customer.google.redirect',
        'namespace' => NULL,
        'prefix' => 'api/v1/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.auth.customer.google.callback' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/auth/customer/google/callback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'throttle:10,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@googleCallback',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@googleCallback',
        'as' => 'api.auth.customer.google.callback',
        'namespace' => NULL,
        'prefix' => 'api/v1/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.auth.customer.google.id-token' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/auth/customer/google/id-token',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'throttle:10,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@googleIdToken',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@googleIdToken',
        'as' => 'api.auth.customer.google.id-token',
        'namespace' => NULL,
        'prefix' => 'api/v1/auth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.products.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\ProductController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\ProductController@index',
        'as' => 'api.catalog.products.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.products.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/products/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\ProductController@show',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\ProductController@show',
        'as' => 'api.catalog.products.show',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.products.preorder-info' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/products/{id}/preorder-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\ProductController@preorderInfo',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\ProductController@preorderInfo',
        'as' => 'api.catalog.products.preorder-info',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.tree' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories/tree',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@tree',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@tree',
        'as' => 'api.catalog.categories.tree',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.featured' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories/featured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@featured',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@featured',
        'as' => 'api.catalog.categories.featured',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@search',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@search',
        'as' => 'api.catalog.categories.search',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.by-genre' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories/by-genre/{genre}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@byGenre',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@byGenre',
        'as' => 'api.catalog.categories.by-genre',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'genre' => 'homme|femme|enfant|mixte',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@index',
        'as' => 'api.catalog.categories.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@show',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@show',
        'as' => 'api.catalog.categories.show',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'slug' => '[a-z0-9-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.products' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories/{slug}/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@products',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@products',
        'as' => 'api.catalog.categories.products',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'slug' => '[a-z0-9-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.breadcrumb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories/{slug}/breadcrumb',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@breadcrumb',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@breadcrumb',
        'as' => 'api.catalog.categories.breadcrumb',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'slug' => '[a-z0-9-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.categories.related' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/categories/{slug}/related',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@related',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\CategoryController@related',
        'as' => 'api.catalog.categories.related',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'slug' => '[a-z0-9-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.catalog.brands.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/brands',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\BrandController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\BrandController@index',
        'as' => 'api.catalog.brands.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.gift-carts.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/gift-carts/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@show',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@show',
        'as' => 'api.gift-carts.show',
        'namespace' => NULL,
        'prefix' => 'api/v1/gift-carts',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.gift-carts.contribute' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/gift-carts/{token}/contribute',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@contribute',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@contribute',
        'as' => 'api.gift-carts.contribute',
        'namespace' => NULL,
        'prefix' => 'api/v1/gift-carts',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.gift-carts.contributions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/gift-carts/{token}/contributions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@contributions',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@contributions',
        'as' => 'api.gift-carts.contributions',
        'namespace' => NULL,
        'prefix' => 'api/v1/gift-carts',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.webhooks.fedapay' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/webhooks/fedapay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:60,1',
          2 => 'fedapay.signature',
        ),
        'uses' => 'Modules\\Payment\\Http\\Controllers\\PaymentWebhookController@fedapay',
        'controller' => 'Modules\\Payment\\Http\\Controllers\\PaymentWebhookController@fedapay',
        'as' => 'api.webhooks.fedapay',
        'namespace' => NULL,
        'prefix' => 'api/v1/webhooks',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.me' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\AuthController@me',
        'controller' => 'Modules\\User\\Http\\Controllers\\AuthController@me',
        'as' => 'api.admin.me',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\AuthController@logout',
        'controller' => 'Modules\\User\\Http\\Controllers\\AuthController@logout',
        'as' => 'api.admin.logout',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\AuthController@refresh',
        'controller' => 'Modules\\User\\Http\\Controllers\\AuthController@refresh',
        'as' => 'api.admin.refresh',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.users.super-admins.count' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/users/super-admins/count',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:users.view',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\UserController@countSuperAdmins',
        'controller' => 'Modules\\User\\Http\\Controllers\\UserController@countSuperAdmins',
        'as' => 'api.admin.users.super-admins.count',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/users',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:users.view',
        ),
        'as' => 'api.admin.users.index',
        'uses' => 'Modules\\User\\Http\\Controllers\\UserController@index',
        'controller' => 'Modules\\User\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.users.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:users.create',
        ),
        'as' => 'api.admin.users.store',
        'uses' => 'Modules\\User\\Http\\Controllers\\UserController@store',
        'controller' => 'Modules\\User\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.users.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:users.view',
        ),
        'as' => 'api.admin.users.show',
        'uses' => 'Modules\\User\\Http\\Controllers\\UserController@show',
        'controller' => 'Modules\\User\\Http\\Controllers\\UserController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.users.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:users.update',
        ),
        'as' => 'api.admin.users.update',
        'uses' => 'Modules\\User\\Http\\Controllers\\UserController@update',
        'controller' => 'Modules\\User\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.users.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:users.delete',
        ),
        'as' => 'api.admin.users.destroy',
        'uses' => 'Modules\\User\\Http\\Controllers\\UserController@destroy',
        'controller' => 'Modules\\User\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.profile.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\ProfileController@show',
        'controller' => 'Modules\\User\\Http\\Controllers\\ProfileController@show',
        'as' => 'api.admin.profile.show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/profile',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\ProfileController@update',
        'controller' => 'Modules\\User\\Http\\Controllers\\ProfileController@update',
        'as' => 'api.admin.profile.update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/profile',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.profile.avatar.upload' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/profile/avatar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\ProfileController@uploadAvatar',
        'controller' => 'Modules\\User\\Http\\Controllers\\ProfileController@uploadAvatar',
        'as' => 'api.admin.profile.avatar.upload',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/profile',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.profile.avatar.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/profile/avatar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\ProfileController@deleteAvatar',
        'controller' => 'Modules\\User\\Http\\Controllers\\ProfileController@deleteAvatar',
        'as' => 'api.admin.profile.avatar.delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/profile',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.profile.password.change' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/profile/change-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\ProfileController@changePassword',
        'controller' => 'Modules\\User\\Http\\Controllers\\ProfileController@changePassword',
        'as' => 'api.admin.profile.password.change',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/profile',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.profile.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
        ),
        'uses' => 'Modules\\User\\Http\\Controllers\\ProfileController@destroy',
        'controller' => 'Modules\\User\\Http\\Controllers\\ProfileController@destroy',
        'as' => 'api.admin.profile.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/profile',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.authenticity.generate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/authenticity/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:authenticity.manage',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@generate',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@generate',
        'as' => 'api.admin.authenticity.generate',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/authenticity',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.authenticity.analytics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/authenticity/analytics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:authenticity.manage',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@analytics',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@analytics',
        'as' => 'api.admin.authenticity.analytics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/authenticity',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.authenticity.mark-fake' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/authenticity/{qrCode}/mark-fake',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:authenticity.manage',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@markAsFake',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@markAsFake',
        'as' => 'api.admin.authenticity.mark-fake',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/authenticity',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.authenticity.product-stats' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/authenticity/product/{productId}/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:authenticity.manage',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@productStats',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\AuthenticityController@productStats',
        'as' => 'api.admin.authenticity.product-stats',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/authenticity',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.seasons' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/collections-seasons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@seasons',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@seasons',
        'as' => 'api.admin.collections.seasons',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.featured' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/collections-featured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@featured',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@featured',
        'as' => 'api.admin.collections.featured',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.products.available' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/collections/products/available',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@availableProducts',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@availableProducts',
        'as' => 'api.admin.collections.products.available',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.products.bulk-move' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections/products/bulk-move',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@bulkMoveProducts',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@bulkMoveProducts',
        'as' => 'api.admin.collections.products.bulk-move',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/collections',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.collections.index',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.create',
        ),
        'as' => 'api.admin.collections.store',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@store',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/collections/{collection}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.collections.show',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@show',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/collections/{collection}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'as' => 'api.admin.collections.update',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@update',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/collections/{collection}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'as' => 'api.admin.collections.destroy',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@destroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.toggle-featured' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections/{id}/toggle-featured',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@toggleFeatured',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@toggleFeatured',
        'as' => 'api.admin.collections.toggle-featured',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.toggle-active' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections/{id}/toggle-active',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@toggleActive',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@toggleActive',
        'as' => 'api.admin.collections.toggle-active',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.products.add' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections/{id}/products/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@addProducts',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@addProducts',
        'as' => 'api.admin.collections.products.add',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.products.remove' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections/{id}/products/remove',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@removeProducts',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@removeProducts',
        'as' => 'api.admin.collections.products.remove',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.products.sync' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections/{id}/products/sync',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@syncProducts',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@syncProducts',
        'as' => 'api.admin.collections.products.sync',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.products.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/collections/{id}/products/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@productsStatistics',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@productsStatistics',
        'as' => 'api.admin.collections.products.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/collections/{id}/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@statistics',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@statistics',
        'as' => 'api.admin.collections.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.refresh-counts' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections/{id}/refresh-counts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@refreshCounts',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@refreshCounts',
        'as' => 'api.admin.collections.refresh-counts',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.collections.archive' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/collections/{id}/archive',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@archive',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CollectionController@archive',
        'as' => 'api.admin.collections.archive',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/collections',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/products/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@statistics',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@statistics',
        'as' => 'api.admin.products.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.bulk.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/bulk/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@bulkUpdate',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@bulkUpdate',
        'as' => 'api.admin.products.bulk.update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.bulk.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/bulk/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@bulkDestroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@bulkDestroy',
        'as' => 'api.admin.products.bulk.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.bulk.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/bulk/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@bulkRestore',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@bulkRestore',
        'as' => 'api.admin.products.bulk.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.bulk.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/bulk/force-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@bulkForceDelete',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@bulkForceDelete',
        'as' => 'api.admin.products.bulk.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.export' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@export',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@export',
        'as' => 'api.admin.products.export',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/{id}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.create',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@duplicate',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@duplicate',
        'as' => 'api.admin.products.duplicate',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@restore',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@restore',
        'as' => 'api.admin.products.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/products/{id}/force',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@forceDelete',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@forceDelete',
        'as' => 'api.admin.products.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.update-stock' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/{id}/stock',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@updateStock',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@updateStock',
        'as' => 'api.admin.products.update-stock',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.stock-history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/products/{id}/stock-history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@stockHistory',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@stockHistory',
        'as' => 'api.admin.products.stock-history',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.variations.update-stock' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/{productId}/variations/{variationId}/stock',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@updateVariationStock',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@updateVariationStock',
        'as' => 'api.admin.products.variations.update-stock',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.enable-preorder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/{id}/enable-preorder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@enablePreorder',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@enablePreorder',
        'as' => 'api.admin.products.enable-preorder',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.disable-preorder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/{id}/disable-preorder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@disablePreorder',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@disablePreorder',
        'as' => 'api.admin.products.disable-preorder',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.preorder-info' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/products/{id}/preorder-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@preorderInfo',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@preorderInfo',
        'as' => 'api.admin.products.preorder-info',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.authenticity.stats' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/products/{id}/authenticity/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:authenticity.manage',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@authenticityStats',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@authenticityStats',
        'as' => 'api.admin.products.authenticity.stats',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.products.index',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.create',
        ),
        'as' => 'api.admin.products.store',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@store',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.products.show',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@show',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'as' => 'api.admin.products.update',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@update',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'as' => 'api.admin.products.destroy',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@destroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\ProductController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.tree' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/categories/tree',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@tree',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@tree',
        'as' => 'api.admin.categories.tree',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.move' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/categories/{id}/move',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@move',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@move',
        'as' => 'api.admin.categories.move',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.reorder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/categories/reorder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@reorder',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@reorder',
        'as' => 'api.admin.categories.reorder',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/categories/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@restore',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@restore',
        'as' => 'api.admin.categories.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/categories/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@statistics',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@statistics',
        'as' => 'api.admin.categories.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.breadcrumb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/categories/{id}/breadcrumb',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@breadcrumb',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@breadcrumb',
        'as' => 'api.admin.categories.breadcrumb',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/categories/{id}/force',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@forceDelete',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@forceDelete',
        'as' => 'api.admin.categories.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.bulk.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/categories/bulk/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@bulkDestroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@bulkDestroy',
        'as' => 'api.admin.categories.bulk.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.bulk.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/categories/bulk/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@bulkRestore',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@bulkRestore',
        'as' => 'api.admin.categories.bulk.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.bulk.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/categories/bulk/force-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@bulkForceDelete',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@bulkForceDelete',
        'as' => 'api.admin.categories.bulk.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/categories/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.categories.index',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.create',
        ),
        'as' => 'api.admin.categories.store',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@store',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.categories.show',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@show',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'as' => 'api.admin.categories.update',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@update',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.categories.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'as' => 'api.admin.categories.destroy',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@destroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\CategoryController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/brands/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@restore',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@restore',
        'as' => 'api.admin.brands.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/brands/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@statistics',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@statistics',
        'as' => 'api.admin.brands.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/brands/{id}/force',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@forceDelete',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@forceDelete',
        'as' => 'api.admin.brands.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.bulk.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/brands/bulk/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@bulkDestroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@bulkDestroy',
        'as' => 'api.admin.brands.bulk.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/brands/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.bulk.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/brands/bulk/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@bulkRestore',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@bulkRestore',
        'as' => 'api.admin.brands.bulk.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/brands/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.bulk.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/brands/bulk/force-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@bulkForceDelete',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@bulkForceDelete',
        'as' => 'api.admin.brands.bulk.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/brands/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.update-with-files' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/brands/{brand}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@update',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@update',
        'as' => 'api.admin.brands.update-with-files',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/brands',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.brands.index',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/brands',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.create',
        ),
        'as' => 'api.admin.brands.store',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@store',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/brands/{brand}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.brands.show',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@show',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/brands/{brand}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'as' => 'api.admin.brands.update',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@update',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.brands.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/brands/{brand}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'as' => 'api.admin.brands.destroy',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@destroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\BrandController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/attributes/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@statistics',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@statistics',
        'as' => 'api.admin.attributes.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/attributes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.reorder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/attributes/reorder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@reorder',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@reorder',
        'as' => 'api.admin.attributes.reorder',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/attributes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/attributes/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@restore',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@restore',
        'as' => 'api.admin.attributes.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/attributes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/attributes/{id}/force',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@forceDelete',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@forceDelete',
        'as' => 'api.admin.attributes.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/attributes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.bulk.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/attributes/bulk/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@bulkDestroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@bulkDestroy',
        'as' => 'api.admin.attributes.bulk.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/attributes/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.bulk.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/attributes/bulk/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@bulkRestore',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@bulkRestore',
        'as' => 'api.admin.attributes.bulk.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/attributes/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.bulk.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/attributes/bulk/force-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@bulkForceDelete',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@bulkForceDelete',
        'as' => 'api.admin.attributes.bulk.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/attributes/bulk',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/attributes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.attributes.index',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/attributes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.create',
        ),
        'as' => 'api.admin.attributes.store',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@store',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/attributes/{attribute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'as' => 'api.admin.attributes.show',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@show',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/attributes/{attribute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'as' => 'api.admin.attributes.update',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@update',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.attributes.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/attributes/{attribute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.delete',
        ),
        'as' => 'api.admin.attributes.destroy',
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@destroy',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\AttributeController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.preorder.enable' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/{productId}/preorder/enable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\PreorderController@enable',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\PreorderController@enable',
        'as' => 'api.admin.products.preorder.enable',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products/{productId}/preorder',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.products.preorder.disable' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/products/{productId}/preorder/disable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.update',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\PreorderController@disable',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\PreorderController@disable',
        'as' => 'api.admin.products.preorder.disable',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/products/{productId}/preorder',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.preorders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/preorders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:catalogue.view',
        ),
        'uses' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\PreorderController@index',
        'controller' => 'Modules\\Catalogue\\Http\\Controllers\\Admin\\PreorderController@index',
        'as' => 'api.admin.preorders.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.orders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:orders.view',
        ),
        'as' => 'api.admin.orders.index',
        'uses' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@index',
        'controller' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.orders.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:orders.view',
        ),
        'as' => 'api.admin.orders.show',
        'uses' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@show',
        'controller' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.orders.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:orders.delete',
        ),
        'as' => 'api.admin.orders.destroy',
        'uses' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@destroy',
        'controller' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.orders.items' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/orders/{id}/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:orders.view',
        ),
        'uses' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@items',
        'controller' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@items',
        'as' => 'api.admin.orders.items',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.orders.update-status' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/orders/{id}/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:orders.update',
        ),
        'uses' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@updateStatus',
        'controller' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@updateStatus',
        'as' => 'api.admin.orders.update-status',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.orders.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/orders/{id}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:orders.cancel',
        ),
        'uses' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@cancel',
        'controller' => 'Modules\\Order\\Http\\Controllers\\Admin\\OrderController@cancel',
        'as' => 'api.admin.orders.cancel',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.payments.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/payments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:payments.view',
        ),
        'as' => 'api.admin.payments.index',
        'uses' => 'Modules\\Payment\\Http\\Controllers\\Admin\\PaymentController@index',
        'controller' => 'Modules\\Payment\\Http\\Controllers\\Admin\\PaymentController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.payments.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/payments/{payment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:payments.view',
        ),
        'as' => 'api.admin.payments.show',
        'uses' => 'Modules\\Payment\\Http\\Controllers\\Admin\\PaymentController@show',
        'controller' => 'Modules\\Payment\\Http\\Controllers\\Admin\\PaymentController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.payments.refund' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/payments/{id}/refund',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:payments.refund',
        ),
        'uses' => 'Modules\\Payment\\Http\\Controllers\\Admin\\PaymentController@refund',
        'controller' => 'Modules\\Payment\\Http\\Controllers\\Admin\\PaymentController@refund',
        'as' => 'api.admin.payments.refund',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/customers/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.view',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@statistics',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@statistics',
        'as' => 'api.admin.customers.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.view',
        ),
        'as' => 'api.admin.customers.index',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@index',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.create',
        ),
        'as' => 'api.admin.customers.store',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@store',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/customers/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.view',
        ),
        'as' => 'api.admin.customers.show',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@show',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/customers/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.update',
        ),
        'as' => 'api.admin.customers.update',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@update',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/customers/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.delete',
        ),
        'as' => 'api.admin.customers.destroy',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@destroy',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.suspend' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/customers/{id}/suspend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.update',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@suspend',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@suspend',
        'as' => 'api.admin.customers.suspend',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.activate' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/customers/{id}/activate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.update',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@activate',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@activate',
        'as' => 'api.admin.customers.activate',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.deactivate' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/customers/{id}/deactivate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.update',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@deactivate',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@deactivate',
        'as' => 'api.admin.customers.deactivate',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.bulk.status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/customers/bulk/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.update',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@bulkUpdateStatus',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@bulkUpdateStatus',
        'as' => 'api.admin.customers.bulk.status',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/customers/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.update',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@restore',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@restore',
        'as' => 'api.admin.customers.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.bulk.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/customers/bulk/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.update',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@bulkRestore',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@bulkRestore',
        'as' => 'api.admin.customers.bulk.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.bulk.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/customers/bulk/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.delete',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@bulkDestroy',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@bulkDestroy',
        'as' => 'api.admin.customers.bulk.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/customers/{id}/force',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.delete',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@forceDelete',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@forceDelete',
        'as' => 'api.admin.customers.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.bulk.force-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/customers/bulk/force-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.delete',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@bulkForceDelete',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@bulkForceDelete',
        'as' => 'api.admin.customers.bulk.force-delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.customers.export' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/customers/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:customers.view',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@export',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\Admin\\CustomerController@export',
        'as' => 'api.admin.customers.export',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/customers',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.members.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/settings/members/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.view',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@statistics',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@statistics',
        'as' => 'api.admin.settings.members.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.members.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/settings/members',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.view',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@index',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@index',
        'as' => 'api.admin.settings.members.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/members',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.members.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/settings/members',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@store',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@store',
        'as' => 'api.admin.settings.members.store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/members',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.members.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/settings/members/{member}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.view',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@show',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@show',
        'as' => 'api.admin.settings.members.show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/members/{member}',
        'where' => 
        array (
          'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.members.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/settings/members/{member}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@update',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@update',
        'as' => 'api.admin.settings.members.update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/members/{member}',
        'where' => 
        array (
          'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.members.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/settings/members/{member}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@destroy',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@destroy',
        'as' => 'api.admin.settings.members.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/members/{member}',
        'where' => 
        array (
          'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.members.update-role' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/settings/members/{member}/role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@updateRole',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@updateRole',
        'as' => 'api.admin.settings.members.update-role',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/members/{member}',
        'where' => 
        array (
          'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.members.update-status' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/settings/members/{member}/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@updateStatus',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@updateStatus',
        'as' => 'api.admin.settings.members.update-status',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/members/{member}',
        'where' => 
        array (
          'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'member' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.invitations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/settings/invitations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.view',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@invitations',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@invitations',
        'as' => 'api.admin.settings.invitations.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/invitations',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.invitations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/settings/invitations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@invite',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@invite',
        'as' => 'api.admin.settings.invitations.store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/invitations',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.invitations.bulk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/settings/invitations/bulk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@bulkInvite',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@bulkInvite',
        'as' => 'api.admin.settings.invitations.bulk',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/invitations',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.invitations.resend' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/settings/invitations/{id}/resend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@resendInvitation',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@resendInvitation',
        'as' => 'api.admin.settings.invitations.resend',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/invitations',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.settings.invitations.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/settings/invitations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:settings.update',
        ),
        'uses' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@cancelInvitation',
        'controller' => 'Modules\\Settings\\Http\\Controllers\\Admin\\SettingsMemberController@cancelInvitation',
        'as' => 'api.admin.settings.invitations.cancel',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/settings/invitations',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/promotions/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.view',
        ),
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@statistics',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@statistics',
        'as' => 'api.admin.promotions.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.bulk.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/promotions/bulk/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.delete',
        ),
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@bulkDestroy',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@bulkDestroy',
        'as' => 'api.admin.promotions.bulk.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.bulk.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/promotions/bulk/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.update',
        ),
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@bulkRestore',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@bulkRestore',
        'as' => 'api.admin.promotions.bulk.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/promotions/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.update',
        ),
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@restore',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@restore',
        'as' => 'api.admin.promotions.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/promotions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.view',
        ),
        'as' => 'api.admin.promotions.index',
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@index',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/promotions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.create',
        ),
        'as' => 'api.admin.promotions.store',
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@store',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/promotions/{promotion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.view',
        ),
        'as' => 'api.admin.promotions.show',
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@show',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/promotions/{promotion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.update',
        ),
        'as' => 'api.admin.promotions.update',
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@update',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.promotions.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/promotions/{promotion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:promotions.delete',
        ),
        'as' => 'api.admin.promotions.destroy',
        'uses' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@destroy',
        'controller' => 'Modules\\Promotion\\Http\\Controllers\\Admin\\PromotionController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/reviews/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@statistics',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@statistics',
        'as' => 'api.admin.reviews.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/reviews',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.bulk.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/reviews/bulk/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@bulkApprove',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@bulkApprove',
        'as' => 'api.admin.reviews.bulk.approve',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/reviews',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.bulk.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/reviews/bulk/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@bulkReject',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@bulkReject',
        'as' => 'api.admin.reviews.bulk.reject',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/reviews',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.bulk.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/reviews/bulk/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@bulkDestroy',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@bulkDestroy',
        'as' => 'api.admin.reviews.bulk.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/reviews',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.bulk.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/reviews/bulk/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@bulkRestore',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@bulkRestore',
        'as' => 'api.admin.reviews.bulk.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/reviews',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.restore' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/reviews/{id}/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@restore',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@restore',
        'as' => 'api.admin.reviews.restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/reviews',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/reviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'as' => 'api.admin.reviews.index',
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@index',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/reviews/{review}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'as' => 'api.admin.reviews.show',
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@show',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/reviews/{review}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'as' => 'api.admin.reviews.destroy',
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@destroy',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/reviews/{id}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@approve',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@approve',
        'as' => 'api.admin.reviews.approve',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.reviews.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/reviews/{id}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reviews.manage',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@reject',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\Admin\\ReviewController@reject',
        'as' => 'api.admin.reviews.reject',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipments.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/shipments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.view',
        ),
        'as' => 'api.admin.shipments.index',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@index',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipments.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/shipments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.create',
        ),
        'as' => 'api.admin.shipments.store',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@store',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipments.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/shipments/{shipment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.view',
        ),
        'as' => 'api.admin.shipments.show',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@show',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipments.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/shipments/{shipment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.update',
        ),
        'as' => 'api.admin.shipments.update',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@update',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipments.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/shipments/{shipment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.delete',
        ),
        'as' => 'api.admin.shipments.destroy',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@destroy',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShipmentController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipping-methods.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/shipping-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.view',
        ),
        'as' => 'api.admin.shipping-methods.index',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@index',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipping-methods.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/shipping-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.create',
        ),
        'as' => 'api.admin.shipping-methods.store',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@store',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipping-methods.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/shipping-methods/{shipping_method}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.view',
        ),
        'as' => 'api.admin.shipping-methods.show',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@show',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipping-methods.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/admin/shipping-methods/{shipping_method}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.update',
        ),
        'as' => 'api.admin.shipping-methods.update',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@update',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.shipping-methods.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/shipping-methods/{shipping_method}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:shipping.delete',
        ),
        'as' => 'api.admin.shipping-methods.destroy',
        'uses' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@destroy',
        'controller' => 'Modules\\Shipping\\Http\\Controllers\\Admin\\ShippingMethodController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.notification-settings.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/inventory/notification-settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryNotificationSettingsController@show',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryNotificationSettingsController@show',
        'as' => 'api.admin.inventory.notification-settings.show',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.notification-settings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/inventory/notification-settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryNotificationSettingsController@update',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryNotificationSettingsController@update',
        'as' => 'api.admin.inventory.notification-settings.update',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.low-stock' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/inventory/low-stock',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@lowStock',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@lowStock',
        'as' => 'api.admin.inventory.low-stock',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.movements' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/inventory/movements',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@movements',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@movements',
        'as' => 'api.admin.inventory.movements',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.statistics' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/inventory/statistics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@statistics',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@statistics',
        'as' => 'api.admin.inventory.statistics',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.out-of-stock' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/inventory/out-of-stock',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@outOfStock',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@outOfStock',
        'as' => 'api.admin.inventory.out-of-stock',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/inventory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@index',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@index',
        'as' => 'api.admin.inventory.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.adjust' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/inventory/adjust',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@adjust',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@adjust',
        'as' => 'api.admin.inventory.adjust',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.bulk-adjust' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/inventory/bulk-adjust',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@bulkAdjust',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@bulkAdjust',
        'as' => 'api.admin.inventory.bulk-adjust',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.inventory.export' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/inventory/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:inventory.manage',
        ),
        'uses' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@export',
        'controller' => 'Modules\\Inventory\\Http\\Controllers\\Admin\\InventoryController@export',
        'as' => 'api.admin.inventory.export',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin/inventory',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.dashboard.stats' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/dashboard/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'admin.auth',
          3 => 'throttle:60,1',
          4 => 'permission:reports.view',
        ),
        'uses' => 'Modules\\Core\\Http\\Controllers\\DashboardController@stats',
        'controller' => 'Modules\\Core\\Http\\Controllers\\DashboardController@stats',
        'as' => 'api.admin.dashboard.stats',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@logout',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@logout',
        'as' => 'api.customer.logout',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.me' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@me',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerAuthController@me',
        'as' => 'api.customer.me',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/customer/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerController@updateProfile',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerController@updateProfile',
        'as' => 'api.customer.profile.update',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.profile.change-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/profile/change-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\CustomerController@changePassword',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\CustomerController@changePassword',
        'as' => 'api.customer.profile.change-password',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.addresses.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/addresses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'as' => 'api.customer.addresses.index',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\AddressController@index',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\AddressController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.addresses.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/addresses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'as' => 'api.customer.addresses.store',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\AddressController@store',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\AddressController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.addresses.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/addresses/{address}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'as' => 'api.customer.addresses.show',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\AddressController@show',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\AddressController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.addresses.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/v1/customer/addresses/{address}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'as' => 'api.customer.addresses.update',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\AddressController@update',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\AddressController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.addresses.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/customer/addresses/{address}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'as' => 'api.customer.addresses.destroy',
        'uses' => 'Modules\\Customer\\Http\\Controllers\\AddressController@destroy',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\AddressController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.addresses.set-default' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/addresses/{id}/set-default',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\AddressController@setDefault',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\AddressController@setDefault',
        'as' => 'api.customer.addresses.set-default',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.cart.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\CartController@show',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\CartController@show',
        'as' => 'api.customer.cart.show',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.cart.add-item' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/cart/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\CartController@addItem',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\CartController@addItem',
        'as' => 'api.customer.cart.add-item',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.cart.update-item' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/customer/cart/items/{itemId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\CartController@updateItem',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\CartController@updateItem',
        'as' => 'api.customer.cart.update-item',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.cart.remove-item' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/customer/cart/items/{itemId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\CartController@removeItem',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\CartController@removeItem',
        'as' => 'api.customer.cart.remove-item',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.cart.clear' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/customer/cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\CartController@clear',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\CartController@clear',
        'as' => 'api.customer.cart.clear',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.cart.apply-coupon' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/cart/coupon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\CartController@applyCoupon',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\CartController@applyCoupon',
        'as' => 'api.customer.cart.apply-coupon',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.cart.remove-coupon' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/customer/cart/coupon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\CartController@removeCoupon',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\CartController@removeCoupon',
        'as' => 'api.customer.cart.remove-coupon',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.cart.convert-gift' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/cart/convert-to-gift',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@convert',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@convert',
        'as' => 'api.customer.cart.convert-gift',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.gift-carts.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/gift-carts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@myGiftCarts',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@myGiftCarts',
        'as' => 'api.customer.gift-carts.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.gift-carts.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/gift-carts/{token}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@cancel',
        'controller' => 'Modules\\Cart\\Http\\Controllers\\GiftCartController@cancel',
        'as' => 'api.customer.gift-carts.cancel',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.orders.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Order\\Http\\Controllers\\OrderController@create',
        'controller' => 'Modules\\Order\\Http\\Controllers\\OrderController@create',
        'as' => 'api.customer.orders.create',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.orders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Order\\Http\\Controllers\\OrderController@index',
        'controller' => 'Modules\\Order\\Http\\Controllers\\OrderController@index',
        'as' => 'api.customer.orders.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.orders.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/orders/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Order\\Http\\Controllers\\OrderController@show',
        'controller' => 'Modules\\Order\\Http\\Controllers\\OrderController@show',
        'as' => 'api.customer.orders.show',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.orders.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/orders/{id}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Order\\Http\\Controllers\\OrderController@cancel',
        'controller' => 'Modules\\Order\\Http\\Controllers\\OrderController@cancel',
        'as' => 'api.customer.orders.cancel',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.preorders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/preorders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Order\\Http\\Controllers\\OrderController@preorders',
        'controller' => 'Modules\\Order\\Http\\Controllers\\OrderController@preorders',
        'as' => 'api.customer.preorders.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.reviews.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/reviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\ReviewController@store',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\ReviewController@store',
        'as' => 'api.customer.reviews.store',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.reviews.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/reviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\ReviewController@myReviews',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\ReviewController@myReviews',
        'as' => 'api.customer.reviews.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.reviews.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/customer/reviews/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\ReviewController@update',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\ReviewController@update',
        'as' => 'api.customer.reviews.update',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.reviews.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/customer/reviews/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Reviews\\Http\\Controllers\\ReviewController@destroy',
        'controller' => 'Modules\\Reviews\\Http\\Controllers\\ReviewController@destroy',
        'as' => 'api.customer.reviews.destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.wishlist.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@index',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@index',
        'as' => 'api.customer.wishlist.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.wishlist.add' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@add',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@add',
        'as' => 'api.customer.wishlist.add',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.wishlist.clear' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/customer/wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@clear',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@clear',
        'as' => 'api.customer.wishlist.clear',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.wishlist.check' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/wishlist/{productId}/check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@check',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@check',
        'as' => 'api.customer.wishlist.check',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'productId' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.wishlist.remove' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/customer/wishlist/{productId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@remove',
        'controller' => 'Modules\\Customer\\Http\\Controllers\\WishlistController@remove',
        'as' => 'api.customer.wishlist.remove',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'productId' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.notifications.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/notifications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Notification\\Http\\Controllers\\NotificationController@index',
        'controller' => 'Modules\\Notification\\Http\\Controllers\\NotificationController@index',
        'as' => 'api.customer.notifications.index',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.notifications.unread-count' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/notifications/unread-count',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Notification\\Http\\Controllers\\NotificationController@unreadCount',
        'controller' => 'Modules\\Notification\\Http\\Controllers\\NotificationController@unreadCount',
        'as' => 'api.customer.notifications.unread-count',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.notifications.read-all' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/notifications/read-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Notification\\Http\\Controllers\\NotificationController@markAllAsRead',
        'controller' => 'Modules\\Notification\\Http\\Controllers\\NotificationController@markAllAsRead',
        'as' => 'api.customer.notifications.read-all',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.customer.notifications.read' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/notifications/{id}/read',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth:sanctum',
          3 => 'customer.auth',
          4 => 'throttle:120,1',
        ),
        'uses' => 'Modules\\Notification\\Http\\Controllers\\NotificationController@markAsRead',
        'controller' => 'Modules\\Notification\\Http\\Controllers\\NotificationController@markAsRead',
        'as' => 'api.customer.notifications.read',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[\\da-fA-F]{8}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{4}-[\\da-fA-F]{12}',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yj8Uvs3vzt5r2iCA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:840:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'/home/dev/projets/chrislain/bylin/bylin_api_v2/vendor/laravel/framework/src/Illuminate/Foundation/Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"0000000000000b0d0000000000000000";}}',
        'as' => 'generated::yj8Uvs3vzt5r2iCA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dm8q34KPf0wZM6WV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:182:"static function () {
    return \\response()->json([
        \'success\' => true,
        \'message\' => \'Bylin API is running.\',
        \'environment\' => \\app()->environment(),
    ]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000c0b0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Dm8q34KPf0wZM6WV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:66:"/home/dev/projets/chrislain/bylin/bylin_api_v2/storage/app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000b150000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scramble.docs.ui' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'docs/api',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:1:{s:3:"api";s:7:"default";}s:8:"function";s:337:"function (\\Dedoc\\Scramble\\Generator $generator) use ($api) {
                    $config = \\Dedoc\\Scramble\\Scramble::getGeneratorConfig($api);

                    return view(\'scramble::docs\', [
                        \'spec\' => $generator($config),
                        \'config\' => $config,
                    ]);
                }";s:5:"scope";s:38:"Dedoc\\Scramble\\ScrambleServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000c0c0000000000000000";}}',
        'as' => 'scramble.docs.ui',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Dedoc\\Scramble\\Http\\Middleware\\RestrictedDocsAccess',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scramble.docs.document' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'docs/api.json',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:1:{s:3:"api";s:7:"default";}s:8:"function";s:255:"function (\\Dedoc\\Scramble\\Generator $generator) use ($api) {
                    $config = \\Dedoc\\Scramble\\Scramble::getGeneratorConfig($api);

                    return response()->json($generator($config), options: JSON_PRETTY_PRINT);
                }";s:5:"scope";s:38:"Dedoc\\Scramble\\ScrambleServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000c0e0000000000000000";}}',
        'as' => 'scramble.docs.document',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Dedoc\\Scramble\\Http\\Middleware\\RestrictedDocsAccess',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
